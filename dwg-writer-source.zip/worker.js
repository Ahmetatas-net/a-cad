self.onmessage=async ({data:{data,glue,wasm}})=>{
  const url=URL.createObjectURL(new Blob([glue],{type:'text/javascript'}));
  try{
    const raw=Uint8Array.from(atob(wasm),c=>c.charCodeAt(0));
    const binary=await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
    const m=await import(url);
    await m.default({module_or_path:binary});
    const out=m.encode_dwg(data);self.postMessage({out},[out.buffer]);
  }catch(e){self.postMessage({error:String(e?.message||e)});}finally{URL.revokeObjectURL(url);}
};
