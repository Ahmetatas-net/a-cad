# Browser DWG writer

The browser uses acadrust 0.6.8 (MPL-2.0) to encode AC1027 DWG, with wasm-bindgen 0.2.114.
The original, unmodified crate source is included as vendor/acadrust-0.6.8.crate (a gzip tar archive).
https://crates.io/crates/acadrust/0.6.8

Build with Rust 1.93.1 and wasm-bindgen-cli 0.2.114.

    rustup target add wasm32-unknown-unknown
    cargo build --locked --target wasm32-unknown-unknown --release
    wasm-bindgen --target web --out-dir dist target/wasm32-unknown-unknown/release/drawing_writer.wasm

The application embeds the JS module and gzipped WASM and loads them from worker.js.
Library licenses and notices are included under notices/.
