use acadrust::{DwgWriter, DxfReader};
use acadrust::types::DxfVersion;
use std::io::Cursor;
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn encode_dwg(input: Vec<u8>) -> Result<Vec<u8>, String> {
    let reader = DxfReader::from_reader(Cursor::new(input)).map_err(|e| e.to_string())?;
    let mut drawing = reader.read().map_err(|e| e.to_string())?;
    if drawing.entities().next().is_none() {
        return Err("Çizim boş.".into());
    }
    drawing.version = DxfVersion::AC1027;
    let mut output = Cursor::new(Vec::new());
    DwgWriter::write_to_writer(&mut output, &drawing).map_err(|e| e.to_string())?;
    Ok(output.into_inner())
}
